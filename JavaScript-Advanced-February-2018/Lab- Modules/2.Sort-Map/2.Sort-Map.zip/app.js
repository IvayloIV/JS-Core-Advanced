let mapSort = require('./SortMap');

result.mapSort = mapSort;